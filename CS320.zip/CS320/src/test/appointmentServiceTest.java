//Author Name: Jordan Wentworth
//Date: 03/30/2022
//Course ID: CS 320

package test;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import main.appointment;
import main.appointmentService;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;

@TestMethodOrder(OrderAnnotation.class)
public class appointmentServiceTest {

@Test
@DisplayName("Test to Update Appointment Description.")
@Order(1)
void testUpdateappointDescript() {
appointmentService service = new appointmentService();
service.addappointment("TaskDescript", null);
service.updateappointDescript("...", "1");
//service.displayappointList();
assertEquals(service.getappointment("...").getappointDescript(), "Appointment Description was not updated.");
	}

@Test
@DisplayName("Test to Update Appointment Date.")
@Order(1)
void testUpdateappointDate() {
appointmentService service = new appointmentService();
service.addappointment("TaskDescript", null);
service.updateappointDate(null, "...");
//service.displayappointList();
assertEquals(service.getappointment("...").getappointDate(), "Appointment Date was not updated.");
	}


@Test
@DisplayName("Test to ensure that service correctly deletes appointment.")
@Order(2)
void testDeleteappointment() {
appointmentService service = new appointmentService();
service.addappointment("AppointDescript", null);
service.deleteappointment("2");
ArrayList<appointment> appointListEmpty = new ArrayList<appointment>();
//service.displayappointList();
assertEquals(service.appointList, appointListEmpty, "The task was not deleted.");
}

@Test
@DisplayName("Test to ensure that service can add a appointment.")
@Order(3)
void testAddappointment() {
appointmentService service = new appointmentService();
service.addappointment("appointDescript", null);
//service.displayappointList();
assertNotNull(service.getappointment("3"), "Appointment was not added correctly.");
}

}