//Author Name: Jordan Wentworth
//Date: 03/30/2022
//Course ID: CS 320
	
package test;
import org.junit.jupiter.api.Test;

import main.appointment;

import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class appointmentTest {
@DisplayName("Appointment ID cannot have more than 10 characters")
void appointIDWithMoreThanTenCharacters() {
appointment appointment = new appointment("appointDescript", null);
if(appointment.appointID().length() > 10) {
fail("Appointment ID has more than 10 characters.");
}
}

@Test
@DisplayName("Appointment Description cannot have more than 50 characters")
void testAppointDescriptWithMoreThanFiftyCharacters() {
appointment appointment = new appointment("namename", null);
if(appointment.getappointDescript().length() > 50) {
fail("Appointment Description has more than 50 characters.");
}
}

@Test
@DisplayName("Appointment Description shall not be null")
void testappointDescriptionNotNull() {
appointment appointment = new appointment(null, null);
assertNotNull(appointment.getappointDescript(), "Appointment Description was null.");
}
}
