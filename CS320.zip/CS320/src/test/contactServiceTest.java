//Author Name: Jordan Wentworth
//Date: 03/18/2022
//Course ID: CS 320

package test;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import main.contact;
import main.contactService;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;

@TestMethodOrder(OrderAnnotation.class)
public class contactServiceTest {

@Test
@DisplayName("Test to Update First Name.")
@Order(1)
void testUpdateFirstName() {
contactService service = new contactService();
service.addContact("Jordan", "Wentworth", "5555551111", "123 First Street");
service.updateFirstName("JJ", "1");
//service.displayContactList();
assertEquals("JJ",service.getcontact("1").getFirstName(), "First name was not updated.");
}

@Test
@DisplayName("Test to Update Last Name.")
@Order(2)
void testUpdateLastName() {
contactService service = new contactService();
service.addContact("Jordan", "Wentworth", "5555551111", "123 First Street");
service.updateLastName("WW", "2");
//service.displayContactList();
assertEquals("WW",service.getcontact("2").getLastName(), "Last name was not updated.");
}

@Test
@DisplayName("Test to update phone number.")
@Order(3)
void testUpdatePhoneNumber() {
contactService service = new contactService();
service.addContact("Jordan", "Wentworth", "5555551111", "123 First Street");
service.updateNumber("9991116666", "3");
//service.displayContactList();
assertEquals("9991116666",service.getcontact("3").getNumber(), "Phone number was not updated.");
}

@Test
@DisplayName("Test to update address.")
@Order(4)
void testUpdateAddress() {
contactService service = new contactService();
service.addContact("Jordan", "Wentworth", "5555551111", "123 First Street");
service.updateAddress("321 Second Street", "4");
//service.displayContactList();
assertEquals("321 Second Street",service.getcontact("4").getAddress(), "Address was not updated.");
}

@Test
@DisplayName("Test to ensure that service correctly deletes contacts.")
@Order(5)
void testDeleteContact() {
contactService service = new contactService();
service.addContact("Jordan", "Wentworth", "5555551111", "123 First Street");
service.deleteContact("5");
ArrayList<contact> contactListEmpty = new ArrayList<contact>();
//service.displayContactList();
assertEquals(service.contactList, contactListEmpty, "The contact was not deleted.");
}

@Test
@DisplayName("Test to ensure that service can add a contact.")
@Order(6)
void testAddContact() {
contactService service = new contactService();
service.addContact("Jordan", "Wentworth", "5555551111", "123 First Street");
//service.displayContactList();
assertNotNull(service.getcontact("6"), "Contact was not added correctly.");
}

}