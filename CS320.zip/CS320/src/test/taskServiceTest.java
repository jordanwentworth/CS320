//Author Name: Jordan Wentworth
//Date: 03/26/2022
//Course ID: CS 320

package test;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import main.task;
import main.taskService;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;

@TestMethodOrder(OrderAnnotation.class)
public class taskServiceTest {

@Test
@DisplayName("Test to Update Task Name.")
@Order(1)
void testUpdatetaskName() {
taskService service = new taskService();
service.addtask("TaskName", "TaskDescript");
service.updatetaskName("namename", "1");
//service.displaytaskList();
assertEquals("namename",service.gettask("1").gettaskName(), "Task name was not updated.");
}

@Test
@DisplayName("Test to Update Task Description.")
@Order(2)
void testUpdatetaskDescript() {
taskService service = new taskService();
service.addtask("TaskName", "TaskDescript");
service.updatetaskDescript("namename", "2");
//service.displaytaskList();
assertEquals("name",service.gettask("2").gettaskDescript(), "Task Description was not updated.");
}

@Test
@DisplayName("Test to ensure that service correctly deletes task.")
@Order(3)
void testDeletetask() {
taskService service = new taskService();
service.addtask("TaskName", "TaskDescript");
service.deletetask("3");
ArrayList<task> taskListEmpty = new ArrayList<task>();
//service.displaytaskList();
assertEquals(service.taskList, taskListEmpty, "The task was not deleted.");
}

@Test
@DisplayName("Test to ensure that service can add a task.")
@Order(4)
void testAddtask() {
taskService service = new taskService();
service.addtask("TaskName", "TaskDescript");
//service.displaytaskList();
assertNotNull(service.gettask("4"), "Task was not added correctly.");
}

}