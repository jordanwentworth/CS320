//Author Name: Jordan Wentworth
//Date: 03/18/2022
//Course ID: CS 320
	
package test;
import org.junit.jupiter.api.Test;

import main.contact;

import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class contactTest {
@DisplayName("Contact ID cannot have more than 10 characters")
void testContactIDWithMoreThanTenCharacters() {
contact contact = new contact("FirstName","LastName","PhoneNumbr","Address");
if(contact.getContactID().length() > 10) {
fail("Contact ID has more than 10 characters.");
}
}

@Test
@DisplayName("Contact First Name cannot have more than 10 characters")
void testContactFirstNameWithMoreThanTenCharacters() {
contact contact = new contact("namename","LastName","PhoneNumber","Address");
if(contact.getFirstName().length() > 10) {
fail("First Name has more than 10 characters.");
}
}

@Test
@DisplayName("Contact Last Name cannot have more than 10 characters")
void testContactLastNameWithMoreThanTenCharacters() {
contact contact = new contact("FirstName","namename","PhoneNumber","Address");
if(contact.getLastName().length() > 10) {
fail("Last Name has more than 10 characters.");
}
}

@Test
@DisplayName("Contact phone number is exactly 10 characters")
void testContactNumberWithMoreThanTenCharacters() {
contact contact = new contact("FirstName", "LastName", "55555555555","Address");
if(contact.getNumber().length() != 10) {
fail("Phone number length does not equal 10.");
}
}

@Test
@DisplayName("Contact address cannot have more than 30 characters")
void testContactAddressWithMoreThanThirtyCharacters() {
contact contact = new contact("FirstName","LastName","PhoneNumber","123456789 is nine characters long"
+ "123456789 is another nine characters long");
if(contact.getAddress().length() > 30) {
fail("Address has more than 30 characters.");
}
}

@Test
@DisplayName("Contact First Name shall not be null")
void testContactFirstNameNotNull() {
contact contact = new contact(null, "LastName","PhoneNumber","Address");
assertNotNull(contact.getFirstName(), "First name was null.");
}

@Test
@DisplayName("Contact Last Name shall not be null")
void testContactLastNameNotNull() {
contact contact = new contact("FirstName", null,"PhoneNumbr","Address");
assertNotNull(contact.getLastName(), "Last name was null.");
}

@Test
@DisplayName("Contact Phone Number shall not be null")
void testContactPhoneNotNull() {
contact contact = new contact("FirstName", "LastName", null,"Address");
assertNotNull(contact.getNumber(), "Phone number was null.");
}

@Test
@DisplayName("Contact Address shall not be null")
void testContactAddressNotNull() {
contact contact = new contact("FirstName", "LastName","PhoneNumbr",null);
assertNotNull(contact.getAddress(), "Address was null.");
}
}
