//Author Name: Jordan Wentworth
//Date: 03/26/2022
//Course ID: CS 320
	
package test;
import org.junit.jupiter.api.Test;

import main.task;

import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class taskTest {
@DisplayName("Task ID cannot have more than 10 characters")
void testtaskIDWithMoreThanTenCharacters() {
task task = new task("TaskName","TaskDescript");
if(task.gettaskID().length() > 10) {
fail("Task ID has more than 10 characters.");
}
}

@Test
@DisplayName("Task Name cannot have more than 20 characters")
void testTaskNameWithMoreThanTwentyCharacters() {
task task = new task("namename","TaskDescript");
if(task.gettaskName().length() > 20) {
fail("Task Name has more than 20 characters.");
}
}

@Test
@DisplayName("Task Description cannot have more than 50 characters")
void testTaskDescriptWithMoreThanFiftyCharacters() {
task task = new task("TaskName","namename");
if(task.gettaskDescript().length() > 50) {
fail("Last Name has more than 50 characters.");
}
}

@Test
@DisplayName("Task Name shall not be null")
void testTaskNameNotNull() {
task task = new task(null, "TaskDescript");
assertNotNull(task.gettaskName(), "Task name was null.");
}

@Test
@DisplayName("Task Description shall not be null")
void testTaskDescriptionNotNull() {
task task = new task("TaskName", null);
assertNotNull(task.gettaskDescript(), "Task Description was null.");
}
}
