//Author Name: Jordan Wentworth
//Date: 03/30/2022
//Course ID: CS 320

package main;
import java.util.ArrayList;
import java.util.Date;

public class appointmentService {
public ArrayList<appointment> appointList = new ArrayList<appointment>();

public void displayappointList() {
for(int counter = 0; counter < appointList.size(); counter++) {
System.out.println("\t Appointment ID: " + appointList.get(counter).appointID());
System.out.println("\t Appointment Description: " + appointList.get(counter).getappointDescript());
}
}
//Add appointment.
public void addappointment(String appointDescript, Date appointDate) {
appointment appointment = new appointment(appointDescript, appointDate);
appointList.add(appointment);

}

public appointment getappointment(String appointID) {
appointment appointment = new appointment(null, null);
for(int counter = 0; counter < appointList.size(); counter++) {
if(appointList.get(counter).appointID().contentEquals(appointID)) {
appointment = appointList.get(counter);
}
}
return appointment;
}

//Delete appointment.
public void deleteappointment(String appointID) {
for(int counter = 0; counter < appointList.size(); counter++) {
if(appointList.get(counter).appointID().equals(appointID)) {
appointList.remove(counter);
break;
}
if(counter == appointList.size()-1) {
System.out.println("Appointment ID: " + appointID + " not found.");
}
}
}

//Update the appointment description.
public void updateappointDescript(String updatedString, String appointID) {
for(int counter = 0; counter < appointList.size(); counter++) {
if(appointList.get(counter).appointID().equals(appointID)) {
appointList.get(counter).setappointDescript(updatedString);
break;
}
if(counter == appointList.size()-1) {
System.out.println("Appointment ID: " + appointID + " not found.");
}
}
}

//Update the appointment date.
public void updateappointDate(Date newDate, String appointID) {
for(int counter = 0; counter < appointList.size(); counter++) {
if(appointList.get(counter).appointID().equals(appointID)) {
appointList.get(counter).setappointDate(newDate);
break;
}
if(counter == appointList.size()-1) {
System.out.println("Appointment ID: " + appointID + " not found.");
}
}
}

}
