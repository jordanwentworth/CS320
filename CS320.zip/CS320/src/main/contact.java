//Author Name: Jordan Wentworth
//Date: 03/18/2022
//Course ID: CS 320

package main;
import java.util.concurrent.atomic.AtomicLong;

public class contact {
private String contactID = "";
private String firstName;
private String lastName;
private String Number;
private String Address;
private static AtomicLong idGenerator = new AtomicLong();

public contact(String firstName, String lastName, String number, String address)  {

//CONTACTID
this.contactID = String.valueOf(idGenerator.getAndIncrement());

//FIRSTNAME

if (firstName == null || firstName.isBlank()) {

this.firstName = "NULL";

} else if(firstName.length() > 10) {
this.firstName = firstName.substring(0, 10);
} else {
 this.firstName = firstName;
}

//LASTNAME
if (lastName == null || lastName.isBlank()) {
this.lastName = "NULL";
} else if(lastName.length() > 10) {
this.lastName = lastName.substring(0,10);
} else {
this.lastName = lastName;
}
//NUMBER
if (number == null || number.isBlank() || number.length() != 10) {
this.Number = "5555555555";
} else {
this.Number = number;
}
//ADDRESS
if (address == null || address.isBlank()) {
this.Address = "NULL";
} else if(address.length() > 30) {
this.Address = address.substring(0,30);
} else {
this.Address = address;
}
}

//GETTERS
public String getContactID() {
return contactID;
}

public String getFirstName() {
return firstName;
}

public String getLastName() {
return lastName;
}

public String getNumber() {
return Number;
}

public String getAddress() {
return Address;
}

//SETTERS
public void setFirstName(String firstName) {
if (firstName == null || firstName.isBlank()) {
this.firstName = "NULL";

} else if(firstName.length() > 10) {
this.firstName = firstName.substring(0, 10);
} else {
this.firstName = firstName;
}
}

public void setLastName(String lastName) {
if (lastName == null || lastName.isBlank()) {
this.lastName = "NULL";
} else if(lastName.length() > 10) {
this.lastName = lastName.substring(0,10);
} else {
this.lastName = lastName;
}
}

public void setNumber(String number) {
if (number == null || number.isBlank() || number.length() != 10) {
this.Number = "5555555555";
} else {
this.Number = number;
}
}

public void setAddress(String address) {
if (address == null || address.isBlank()) {
this.Address = "NULL";
} else if(address.length() > 30) {
this.Address = address.substring(0,30);
} else {
this.Address = address;
}
}
}