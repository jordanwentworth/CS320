//Author Name: Jordan Wentworth
//Date: 03/26/2022
//Course ID: CS 320

package main;
import java.util.concurrent.atomic.AtomicLong;

public class task {
private String taskID = "";
private String taskName;
private String taskDescript;
private static AtomicLong idGenerator = new AtomicLong();

public task(String taskName, String taskDescript)  {

//taskID
this.taskID = String.valueOf(idGenerator.getAndIncrement());

//taskName
if (taskName == null || taskName.isBlank()) {

this.taskName = "NULL";

} else if(taskName.length() > 20) {
this.taskName = taskName.substring(0, 20);
} else {
 this.taskName = taskName;
}

//taskDescript
if (taskDescript == null || taskDescript.isBlank()) {
this.taskDescript = "NULL";
} else if(taskDescript.length() > 50) {
this.taskDescript = taskDescript.substring(0,50);
} else {
this.taskDescript = taskDescript;
}
}
//GETTERS
public String gettaskID() {
return taskID;
}

public String gettaskName() {
return taskName;
}

public String gettaskDescript() {
return taskDescript;
}

//SETTERS
public void settaskName(String taskName) {
if (taskName == null || taskName.isBlank()) {
this.taskName = "NULL";

} else if(taskName.length() > 20) {
this.taskName = taskName.substring(0, 20);
} else {
this.taskName = taskName;
}
}

public void settaskDescript(String taskDescript) {
if (taskDescript == null || taskDescript.isBlank()) {
this.taskDescript = "NULL";
} else if(taskDescript.length() > 50) {
this.taskDescript = taskDescript.substring(0,50);
} else {
this.taskDescript = taskDescript;
}
}
}