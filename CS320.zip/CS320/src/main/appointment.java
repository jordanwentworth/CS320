//Author Name: Jordan Wentworth
//Date: 03/30/2022
//Course ID: CS 320

package main;
import java.util.concurrent.atomic.AtomicLong;
import java.util.Date;

public class appointment {
private String appointID = "";
private String appointDescript;
private Date appointDate;
private static AtomicLong idGenerator = new AtomicLong();

public appointment(String appointDescript, Date appointDate)  {

//appointID
this.appointID = String.valueOf(idGenerator.getAndIncrement());

//appointDescript
if (appointDescript == null || appointDescript.isBlank()) {
this.appointDescript = "NULL";
} else if(appointDescript.length() > 50) {
this.appointDescript = appointDescript.substring(0,50);
} else {
this.appointDescript = appointDescript;
}

//appointDate
if (appointDate == null) {
System.out.println("Appointment Date can't be null.");
} else if (appointDate.before(new Date())) {
System.out.println("The appointment can not be in the past.");
} else {
this.appointDate = appointDate;
}
}

//GETTERS
public String appointID() {
return appointID;
}

public String getappointDescript() {
return appointDescript;
}

public Date getappointDate() {
	return appointDate;
}

//SETTERS
public void setappointDescript(String appointDescript) {
if (appointDescript == null || appointDescript.isBlank()) {
this.appointDescript = "NULL";
} else if(appointDescript.length() > 50) {
this.appointDescript = appointDescript.substring(0,50);
} else {
this.appointDescript = appointDescript;
}
}
public void setappointDate(Date appointDate) {
if (appointDate == null) {
System.out.println("Appointment Date can't be null.");
} else if (appointDate.before(new Date())) {
	System.out.println("The appointment can not be in the past.");
    } else {
      this.appointDate = appointDate;
    }
  }
}