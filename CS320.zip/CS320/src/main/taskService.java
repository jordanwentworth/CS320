//Author Name: Jordan Wentworth
//Date: 03/26/2022
//Course ID: CS 320

package main;
import java.util.ArrayList;

public class taskService {
public ArrayList<task> taskList = new ArrayList<task>();

public void displaytaskList() {
for(int counter = 0; counter < taskList.size(); counter++) {
System.out.println("\t Task ID: " + taskList.get(counter).gettaskID());
System.out.println("\t Task Name: " + taskList.get(counter).gettaskName());
System.out.println("\t Task Description: " + taskList.get(counter).gettaskDescript());
}
}
//Add task.
public void addtask(String taskName, String taskDescript) {
task task = new task(taskName, taskDescript);
taskList.add(task);

}

public task gettask(String taskID) {
task task = new task(null,null);
for(int counter = 0; counter < taskList.size(); counter++) {
if(taskList.get(counter).gettaskID().contentEquals(taskID)) {
task = taskList.get(counter);
}
}
return task;
}

//Delete task.
public void deletetask(String taskID) {
for(int counter = 0; counter < taskList.size(); counter++) {
if(taskList.get(counter).gettaskID().equals(taskID)) {
taskList.remove(counter);
break;
}
if(counter == taskList.size()-1) {
System.out.println("Task ID: " + taskID + " not found.");
}
}
}

//Update the task name.
public void updatetaskName(String updatedString, String taskID) {
for(int counter = 0; counter < taskList.size(); counter++) {
if(taskList.get(counter).gettaskID().equals(taskID)) {
taskList.get(counter).settaskName(updatedString);
break;
}
if(counter == taskList.size()-1) {
System.out.println("Task ID: " + taskID + " not found.");
}
}
}

//Update the task description.
public void updatetaskDescript(String updatedString, String taskID) {
for(int counter = 0; counter < taskList.size(); counter++) {
if(taskList.get(counter).gettaskID().equals(taskID)) {
taskList.get(counter).settaskDescript(updatedString);
break;
}
if(counter == taskList.size()-1) {
System.out.println("Task ID: " + taskID + " not found.");
}
}
}
}
